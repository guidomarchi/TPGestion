Curso: K3671

N° Grupo: 22

Grupo: 4_FILAS_AFECTADAS

Miembros del Grupo:

Guido Marchi - 2090156

Gabriel Franco Emiliano Acevedo De la Torre - 2026340

Elena Harutyunyan - 1715800

Dante Ball - 1777531

Correo del Miembro Responsable: maguido@frba.utn.edu.ar